package com.CN.FitFusion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.CN.FitFusion.dto.UserDto;
import com.CN.FitFusion.model.Diet;
import com.CN.FitFusion.model.Exercise;
import com.CN.FitFusion.model.User;
import com.CN.FitFusion.service.UserService;


@RestController
@RequestMapping
public class UserController {

	@Autowired
	UserService userService;
	
	
	@GetMapping("/user/all")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('ADMIN')")
	public List<User> getAll(){
		return userService.getAll();
	}
	
	@GetMapping("/user/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('ADMIN')")
	public User getById(@PathVariable Long id){
		return userService.getById(id);
	}
	
	@PutMapping("/user/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('ADMIN')")
	public void updateUser(@RequestBody UserDto userDto, @PathVariable Long id) {
		userService.updateUser(userDto,id);
	}
	
	@DeleteMapping("/user/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('ADMIN')")
	public void deleteById(@PathVariable Long id) {
		userService.delete(id);
	}
	
	
	@GetMapping("/user/exercise/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('CUSTOMER')")
	public List<Exercise> getAllExercisesByUserId(@PathVariable Long id){
		return userService.getAllExercisesByUserId(id);
	}
	
	
	@GetMapping("/user/diet/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('CUSTOMER')")
	public List<Diet> getAllDietsByUserId(@PathVariable Long id){
		return userService.getAllDietsByUserId(id);
	}
	
	 	@PostMapping("/register")
	    @ResponseStatus(HttpStatus.CREATED)
	    public void registerUser(@RequestBody UserDto userRequest) {
	      userService.register(userRequest);
	    }
}
