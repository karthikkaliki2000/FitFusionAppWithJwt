package com.CN.FitFusion.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CN.FitFusion.dto.DietDto;
import com.CN.FitFusion.exception.DietNotFoundException;
import com.CN.FitFusion.model.Diet;
import com.CN.FitFusion.model.User;
import com.CN.FitFusion.repository.DietRepository;
import com.CN.FitFusion.repository.UserRepository;

@Service
public class DietService {
	
	@Autowired
	DietRepository dietRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserService userService;

	public List<Diet> getAllDiets() {
		return dietRepository.findAll();
	}

	public Diet getDietById(Long id) {
		
		return dietRepository.findById(id).orElseThrow(()->new DietNotFoundException("Requested Diet Not Found"));
	}

	public void createDiet(DietDto dietDto, Long userId) {
		
		User user=userService.getById(userId);
		Diet diet=Diet.builder().description(dietDto.getDescription())
				.name(dietDto.getName())
				.user(dietDto.getUser())
				.build();
		user.getDiets().add(diet);
		dietRepository.save(diet);
		
		userRepository.save(user);
		
	}

	public void updateDiet(DietDto dietDto, Long dietId) {
		Diet diet=this.getDietById(dietId);
		 diet=Diet.builder().description(dietDto.getDescription())
				.name(dietDto.getName())
				.user(dietDto.getUser())
				.build();
		dietRepository.save(diet);
		
	}

	public void deleteDiet(Long dietId) {
		dietRepository.deleteById(dietId);
		
	}

}
