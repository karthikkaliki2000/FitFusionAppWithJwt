package com.CN.FitFusion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.CN.FitFusion.dto.ExerciseDto;
import com.CN.FitFusion.model.Exercise;
import com.CN.FitFusion.service.ExerciseService;

@RequestMapping
@RestController
public class ExerciseController {

	@Autowired
	ExerciseService exerciseService;

	@GetMapping("/exercise/all")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('TRAINER')")
	public List<Exercise> getAll(){
		return exerciseService.getAll();
	}
	
	@GetMapping("/exercise/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('TRAINER')")
	public Exercise getById(@PathVariable Long id){
		return exerciseService.getById(id);
	}
	
	@PostMapping("/exercise/create/{userId}")
	@ResponseStatus(HttpStatus.CREATED)
	@PreAuthorize("hasRole('TRAINER')")
	public void createExercise(@RequestBody ExerciseDto exerciseDto, @PathVariable Long userId) {
		exerciseService.createExercise(exerciseDto,userId);
	}
	
	@PutMapping("/exercise/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('TRAINER')")
	public void updateExercise(@RequestBody ExerciseDto exerciseDto, @PathVariable Long id) {
		exerciseService.updateExercise(exerciseDto,id);
	}
	
	@DeleteMapping("/exercise/{id}")
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasRole('TRAINER')")
	public void deleteById(@PathVariable Long id) {
		exerciseService.deleteById(id);
	}
	
}
