package com.CN.FitFusion.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.CN.FitFusion.dto.UserDto;
import com.CN.FitFusion.exception.UserNotFoundException;
import com.CN.FitFusion.model.Diet;
import com.CN.FitFusion.model.Exercise;
import com.CN.FitFusion.model.Role;
import com.CN.FitFusion.model.User;
import com.CN.FitFusion.repository.UserRepository;


@Service
public class UserService {

	@Autowired
	UserRepository userRepository;
	
	 @Autowired
	 private PasswordEncoder passwordEncoder;
	
	public List<User> getAll() {
		
		return userRepository.findAll();
	}

	public User getById(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id).orElseThrow(()->new UserNotFoundException("Requested Userr not found"));
	}

	public void updateUser(UserDto userDto, Long id) {
		User existingUser=this.getById(id);
		existingUser.setAge(userDto.getAge());
		existingUser.setContactNo(userDto.getContactNo());
		existingUser.setDiets(userDto.getDiets());
		existingUser.setEmail(userDto.getEmail());
		existingUser.setExerciseList(userDto.getExerciseList());
		existingUser.setGender(userDto.getGender());
		existingUser.setPassword(userDto.getPassword());
		existingUser.setRoles(userDto.getRoles());
		
		userRepository.save(existingUser);
		
	}

	public void delete(Long id) {
		userRepository.deleteById(id);
		
	}

	public List<Exercise> getAllExercisesByUserId(Long id) {
		User exUser=this.getById(id);
		return exUser.getExerciseList();
	}

	public List<Diet> getAllDietsByUserId(Long id) {
		User exUser=this.getById(id);
		return exUser.getDiets();
	}

	public void register(UserDto userRequest) {
		BCryptPasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();
		 String encodedPassword = bCryptPasswordEncoder.encode(userRequest.getPassword());
		 User user=User.builder().age(userRequest.getAge())
				 .contactNo(userRequest.getContactNo())
				 .diets(userRequest.getDiets())
				 .email(userRequest.getEmail())
				 .exerciseList(userRequest.getExerciseList())
				 .gender(userRequest.getGender())
				 .password(userRequest.getPassword())
				 .roles(userRequest.getRoles())
				 .build();
		 Role role = new Role();
	      Set<Role> roles = new HashSet<>();
	      if(userRequest.getUserType() != null) {
	            if (userRequest.getUserType().equalsIgnoreCase("TRAINER")) {
	                role.setRoleName("ROLE_TRAINER");
	                roles.add(role);
	                user.setRoles(roles);
	            } else if (userRequest.getUserType().equalsIgnoreCase("ADMIN")) {
	                role.setRoleName("ROLE_ADMIN");
	                roles.add(role);
	                user.setRoles(roles);
	            } else {
	                role.setRoleName("ROLE_CUSTOMER");
	                roles.add(role);
	                user.setRoles(roles);
	            }
	        }
	        else {
	            role.setRoleName("ROLE_CUSTOMER");
	            roles.add(role);
	            user.setRoles(roles);
	        }
	        userRepository.save(user);
				 
		
	}

}
