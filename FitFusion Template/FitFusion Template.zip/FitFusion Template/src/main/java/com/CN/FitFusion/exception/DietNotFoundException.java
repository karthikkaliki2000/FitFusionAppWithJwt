package com.CN.FitFusion.exception;

public class DietNotFoundException extends RuntimeException{

	public DietNotFoundException() {
		super();
		
	}

	public DietNotFoundException(String message) {
		super(message);
		
	}

}
