package com.CN.FitFusion.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CN.FitFusion.dto.ExerciseDto;
import com.CN.FitFusion.exception.ExerciseNotFoundException;
import com.CN.FitFusion.model.Exercise;
import com.CN.FitFusion.model.User;
import com.CN.FitFusion.repository.ExerciseRepository;
import com.CN.FitFusion.repository.UserRepository;

@Service
public class ExerciseService {
	
	@Autowired
	ExerciseRepository exerciseRepository;
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserRepository userRepository;
	 

	public List<Exercise> getAll() {
		
		return exerciseRepository.findAll();
	}

	public Exercise getById(Long id) {
		
		return exerciseRepository.findById(id).orElseThrow(()->new ExerciseNotFoundException("Requested Exercise Not Found"));
	}

	public void createExercise(ExerciseDto exerciseDto, Long userId) {
		User user=userService.getById(userId);
		Exercise exercise=Exercise.builder().description(exerciseDto.getDescription())
				.name(exerciseDto.getName())
				.reps(exerciseDto.getReps())
				.sets(exerciseDto.getSets())
				.user(user)
				.build();
		exerciseRepository.save(exercise);
		user.getExerciseList().add(exercise);
		userRepository.save(user);
		
	}

	public void updateExercise(ExerciseDto exerciseDto, Long id) {
		Exercise exercise=Exercise.builder().description(exerciseDto.getDescription())
				.name(exerciseDto.getName())
				.reps(exerciseDto.getReps())
				.sets(exerciseDto.getSets())
				.user(exerciseDto.getUser())
				.build();
		exerciseRepository.save(exercise);
	}

	public void deleteById(Long id) {
		exerciseRepository.deleteById(id);
		
	}
	
	

}
