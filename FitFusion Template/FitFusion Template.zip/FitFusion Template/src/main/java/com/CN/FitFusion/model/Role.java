package com.CN.FitFusion.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Role {
	
	@Id
	private Long id;
	
	private String roleName;
	
	
	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinTable(name = "User_Role",joinColumns = {@JoinColumn(name = "role_id",referencedColumnName = "role_id")}, inverseJoinColumns = {@JoinColumn(name = "user_id",referencedColumnName = "user_id")} )
	private Set<User> users;

}
