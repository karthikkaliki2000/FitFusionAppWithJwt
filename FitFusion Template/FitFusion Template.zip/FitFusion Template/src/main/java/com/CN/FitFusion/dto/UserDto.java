package com.CN.FitFusion.dto;

import java.util.List;
import java.util.Set;

import com.CN.FitFusion.model.Diet;
import com.CN.FitFusion.model.Exercise;
import com.CN.FitFusion.model.Role;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

	 private String email;

     private String password;

     private int age;

     private String gender;

     private Long contactNo;

     private String userType;
     
     private List<Diet> diets;
     
     private List<Exercise> exerciseList;
     
 	private Set<Role> roles;
}
