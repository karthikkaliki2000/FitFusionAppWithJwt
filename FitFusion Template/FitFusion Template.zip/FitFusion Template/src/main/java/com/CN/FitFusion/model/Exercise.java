package com.CN.FitFusion.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Exercise {

	@Id
	private Long id;
	
	private String name;
	
	private String description;
	
	private int sets;
	
	private int reps;
	
	@ManyToOne
	private User user;
	
}
